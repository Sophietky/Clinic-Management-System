console.log('test');

{/* <div class="carousel">
        <button class="carouselBtn carouselLeft">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
        </button>
        <div class="carousel__track-container">
            <ul class="carousel__track">
                <li class="carousel__slide">
                    <img class="carousel_img" src="../Images/sample1.jpg" alt="">
                </li>
                <li class="carousel__slide">
                    <img class="carousel_img" src="../Images/sample2.jpg" alt="">
                </li>
                <li class="carousel__slide">
                    <img class="carousel_img" src="../Images/sample3.png alt="">
                </li>
            </ul>
        </div>
        <button class="carouselBtn carouselRight">
            <i class="fa fa-arrow-right" aria-hidden="true"></i>
        </button>
        <div class="carousel__nav">
            <button class="carousel__indicator current-slide"></button>
            <button class="carousel__indicator"></button>
            <button class="carousel__indicator"></button>
        </div>
    </div> */}